package quiz02;

public class StudentMain {

	public static void main(String[] args) {
		Student st1 = new Student("hong", 1, 15, 28, 33);
		st1.showInfo();
		Student st2 = new Student("park", 2, 37, 46, 58);
		st2.showInfo();
	}
}
