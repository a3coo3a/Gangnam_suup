package quiz17;

public interface SongList {

	public void insertList(String song);
	public void playList();
	public int playLength();
}
