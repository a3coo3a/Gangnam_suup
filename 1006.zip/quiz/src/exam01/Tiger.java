package exam01;

public class Tiger extends Animal{
	public Tiger(String name){
		super(name);
	}
}
