package exam01;

public class MainClass {
	public static void main(String[] args) {
		Tiger t = new Tiger("호돌이");
		//Cat c = new Cat("냐옹이");
		//Dog d = new Dog("멍멍이");
		System.out.println(t.name);
	}
}
