package quiz12;

public class MainClass {
	public static void main(String[] args) {
		Computer com = new Computer();
		com.getMonitor().info();
		System.out.println();
		com.computerInfo();
	}
}
