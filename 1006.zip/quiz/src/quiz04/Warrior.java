package quiz04;

public class Warrior extends Player{
	
	
	void bash() {
		System.out.println("때리기 스킬 사용");
	}
}
