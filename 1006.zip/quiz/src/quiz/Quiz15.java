package quiz;

public class Quiz15 {
	public static void main(String[] args) {
		// quiz08
		
		int a = 1;
		while (a <= 10) {
			System.out.println(a + "번 학생의 출석을 체크합니다.");
			a++;
		}
		
	}
}
