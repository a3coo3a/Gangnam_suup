package quiz;

public class Test02 {

	
	public static void main(String[] args) {
		
		int str = 65;
		
		while(str <= 90) {
			System.out.print((char)str);
			str++;
		}
		
		
	}
}
