package quiz;

import java.util.Scanner;

public class Test01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num;
		
		System.out.println("숫자 하나를 입력하세요");
		num = sc.nextInt();
		
		sc.close();
	}
	
}
