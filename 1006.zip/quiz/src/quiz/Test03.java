package quiz;

import java.util.Scanner;

public class Test03 {

	
	public static void main(String[] args) {
		
		
		
		
	}
}
