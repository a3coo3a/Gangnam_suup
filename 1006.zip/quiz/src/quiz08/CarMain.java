package quiz08;

public class CarMain {
	public static void main(String[] args) {
		Car car = new Car("JEEP");
		car.run();
		
	}
}
