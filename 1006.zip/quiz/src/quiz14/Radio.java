package quiz14;

public class Radio extends Product{
	//500원, radio로 초기화
	public Radio() {
		super(500,"radio");
	}
}
