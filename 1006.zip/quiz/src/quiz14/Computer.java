package quiz14;

public class Computer extends Product{
	// 가격 600원 이름은 com 초기화
	public Computer() {
		super(600,"com");
	}
	
}
