package quiz14;

public class Tv extends Product{
	// 400원, tv로 초기화
	public Tv() {
		super(400,"tv");
	}
}
