package anonymous.basic02;

public interface RemoteControl {
	public void turnOn();		// 전원을 켜다
	public void turnOff();		// 전원을 끄다
	public void volumeUp();		// 소리를 켜다
	public void volumeDown();	// 소리를 끄다
}
