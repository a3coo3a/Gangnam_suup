package ramda.basic;

// 함수적 인터페이스란 - 구현해야하는 추상메서드가 1개인 인터페이스
public interface Say03 {
	public String talking();
}
